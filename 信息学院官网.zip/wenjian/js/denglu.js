const signInBtn = document.getElementById("signIn");
const signUpBtn = document.getElementById("signUp");
const firstForm = document.getElementById("form1");
const secondForm = document.getElementById("form2");
const container = document.querySelector(".container");

signInBtn.addEventListener("click", () => {
    container.classList.remove("right-panel-active");
});

signUpBtn.addEventListener("click", () => {
    container.classList.add("right-panel-active");
});

firstForm.addEventListener("submit", (e) => e.preventDefault());
secondForm.addEventListener("submit", (e) => e.preventDefault());




/*<?php  
	header("Content-Type:text/html; charset=utf-8");
	header("Access-Control-Allow-Origin: *"); //解决跨域
	header('Access-Control-Allow-Methods:post');// 响应类型  
	mysql_connect('localhost','root','root');
	mysql_set_charset('utf-8');//解决中文乱码问题
	mysql_select_db('images'); //选择数据库
    
//  // 接收前端传过来的参数
 $pho_Num = $_POST['pho_Num'];
 $user_Num = $_POST['na'];
 $name = $_POST['email'];
 $pass = $_POST['password'];
 echo $pho_Num."\n"; 
 echo $user_Num."\n"; 
 echo $name."\n"; 
 echo $pass."\n"; 
 
// 把数据放入数据库
 $sql="insert into  user value(null,'$user_Num','$na','$email','$password')";
 
 if (mysql_query($sql)) {
	echo "添加成功";
 }else{
	echo "添加失败";
 
 }
 
?>  */
