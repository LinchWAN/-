window.onload = function (){
	var oImg = document.getElementsByTagName('img')[1];
	var aBtn = document.getElementsByTagName('input');
	var arrImg = ['../wenjian/pic/1-1.png','../wenjian/pic/1-2.png','../wenjian/pic/1-3.jpg'];
	var num = 0; //用于图片切换时的数组下标
	
	aBtn[0].onclick = function (){ //上一张
		num --;
		if ( num < 0 ){
		num = arrImg.length - 1;
		}
		oImg.src = arrImg[num];
	}
	
	aBtn[1].onclick = function (){ //下一张
		num ++;
		if ( num === arrImg.length ){
		num = 0;
		}
		oImg.src = arrImg[num];
	}
	
	
	var num1 = document.getElementsByTagName("img")[2];
	//定义图像地址
	var shuzu = ["../wenjian/pic/jiangzuobaogao1.png","../wenjian/pic/jiangzuobaogao2.png", "../wenjian/pic/jiangzuobaogao3.png","../wenjian/pic/jiangzuobaogao4.png"];
	//获取按钮
	var prev = document.getElementById("pre1");
	var next = document.getElementById("next1");
	var index = 0;
	//点击切换图片
	prev.onclick = function () {
	    index--;
	    //此处让它循环
	    if (index < 0)
	        index = shuzu.length - 1;
	    num1.src = shuzu[index];
	}
	 
	next.onclick = function () {
	    index++;
	    if (index > shuzu.length - 1)
	        index = 0;
	    num1.src = shuzu[index];
	}
	
	
	var num2 = document.getElementsByTagName("img")[5];
	//定义图像地址
	var shuzu2 = ["../wenjian/pic/jiangzuobaogao5.png","../wenjian/pic/jiangzuobaogao6.png","../wenjian/pic/jiangzuobaogao7.png","../wenjian/pic/jiangzuobaogao8.png"];
	//获取按钮
	var prev = document.getElementById("pre2");
	var next = document.getElementById("next2");
	var index = 0;
	//点击切换图片
	prev.onclick = function () {
	    index--;
	    //此处让它循环
	    if (index < 0)
	        index = shuzu2.length- 1;
	    num2.src = shuzu2[index];
	}
	 
	next.onclick = function () {
	    index++;
	    if (index > shuzu2.length - 1)
	        index = 0;
	    num2.src = shuzu2[index];
	}
}


