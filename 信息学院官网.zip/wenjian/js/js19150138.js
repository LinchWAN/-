//$(document).ready(function(){
 // $("#li1").click(function(){
	//  $("#tp1").css({"background-color":"blue"})
 // });
//});

$(document).ready(function(){
  $("#li1").mouseover(function(){
	 // $("#tp1").css({"size":"150%"})
	 // $("#tp1").css({"height": "700px"})
	  //$("#tp1").css({"transition": "size 0.5s"})
	$("#tp1").animate({
		width:"700px",
		height:"700px"
	},"fast");
		$("#tp1").css({"left": "500px"})
		$("#tp1").css({"transition": "all 1s ease"})
		//$("#tp1").css({"top": "300px"})
	$("#tp2").animate({
		width:"340px",
		height:"340px"
	},"fast");
		$("#tp2").css({"left": "1250px"})
		$("#tp2").css({"top": "200px"})
		$("#tp2").css({"transition": "all 1s ease"})
		
	$("#tp3").animate({
		width:"340px",
		height:"340px"
	},"fast");
		$("#tp3").css({"left": "1250px"})
		$("#tp3").css({"top": "550px"})
		$("#tp3").css({"transition": "all 1s ease"})
  })
  $("#li1").mouseout(function(){
  	  //$("#tp1").css({"size":"100%"})
  	 // $("#tp1").css({"height": "500px"})
  	  //$("#tp1").css({"transition": "size 2s"})
  	 $("#tp1").animate({
  	 	width:"400px",
  	 	height:"400px"
  	 },"fast");
		$("#tp1").css({"left": "500px"})
		$("#tp1").css({"transition": "all 1s ease"})
	 
	 $("#tp2").animate({
	 		width:"400px",
	 		height:"400px"
	},"fast");
	 	$("#tp3").css({"left": "1100px"})
	 	$("#tp3").css({"top": "205px"})
	 	$("#tp2").css({"transition": "all 1s ease"})
	 		
	$("#tp3").animate({
		width:"400px",
		height:"400px"
	},"fast");
		$("#tp2").css({"left": "800px"})
	 	$("#tp2").css({"top": "350px"})
	 	$("#tp3").css({"transition": "all 1s ease"})
	 })
  
					$("#tp1").mouseover(function(){
						$("#tp1").animate({
							width:"700px",
							height:"700px"
						},"fast");
							$("#tp1").css({"left": "500px"})
							$("#tp1").css({"transition": "all 1s ease"})
							
						$("#tp2").animate({
							width:"340px",
							height:"340px"
						},"fast");
							$("#tp2").css({"left": "1250px"})
							$("#tp2").css({"top": "200px"})
							$("#tp2").css({"transition": "all 1s ease"})
							
						$("#tp3").animate({
							width:"340px",
							height:"340px"
						},"fast");
							$("#tp3").css({"left": "1250px"})
							$("#tp3").css({"top": "550px"})
							$("#tp3").css({"transition": "all 1s ease"})
					})
					$("#tp1").mouseout(function(){
						 $("#tp1").animate({
						 	width:"400px",
						 	height:"400px"
						 },"fast");
							$("#tp1").css({"left": "500px"})
							$("#tp1").css({"transition": "all 1s ease"})
						 
						 $("#tp2").animate({
						 		width:"400px",
						 		height:"400px"
						},"fast");
						 	$("#tp2").css({"left": "800px"})
						 	$("#tp2").css({"top": "350px"})
						 	$("#tp2").css({"transition": "all 1s ease"})
						 		
						$("#tp3").animate({
							width:"400px",
							height:"400px"
						},"fast");
						 	$("#tp3").css({"left": "1100px"})
						 	$("#tp3").css({"top": "205px"})
						 	$("#tp3").css({"transition": "all 1s ease"})
						 })
//*************************************************
  $("#li2").mouseover(function(){
	  //图片一去哪
  	$("#tp1").animate({
  		width:"350px",
  		height:"350px"
  	},"fast");
  		$("#tp1").css({"left": "200px"})
  		$("#tp1").css({"transition": "all 1s ease"})
		//图片二去哪
  	$("#tp2").animate({
  		width:"700px",
  		height:"700px"
  	},"fast");
  		$("#tp2").css({"left": "650px"})
  		$("#tp2").css({"top": "200px"})
  		$("#tp2").css({"transition": "all 1s ease"})
  		//图片三去哪
  	$("#tp3").animate({
  		width:"340px",
  		height:"340px"
  	},"fast");
  		$("#tp3").css({"left": "1450px"})
  		//$("#tp3").css({"top": "550px"})
  		$("#tp3").css({"transition": "all 1s ease"})
  })
  //***********************************************
  $("#li2").mouseout(function(){
  	  //$("#tp1").css({"size":"100%"})
  	 // $("#tp1").css({"height": "500px"})
  	  //$("#tp1").css({"transition": "size 2s"})
  	 $("#tp1").animate({
  	 	width:"400px",
  	 	height:"400px"
  	 },"fast");
  		$("#tp1").css({"left": "500px"})
  		$("#tp1").css({"transition": "all 1s ease"})
  	 
  	 $("#tp2").animate({
  	 		width:"400px",
  	 		height:"400px"
  	},"fast");
  	 	$("#tp2").css({"left": "800px"})
  	 	$("#tp2").css({"top": "350px"})
  	 	$("#tp2").css({"transition": "all 1s ease"})
  	 		
  	$("#tp3").animate({
  		width:"400px",
  		height:"400px"
  	},"fast");
  	 	$("#tp3").css({"left": "1100px"})
  	 	$("#tp3").css({"top": "205px"})
  	 	$("#tp3").css({"transition": "all 1s ease"})
  	 })
	 
						//*************************************************
						  $("#tp2").mouseover(function(){
							  //图片一去哪
						  	$("#tp1").animate({
						  		width:"350px",
						  		height:"350px"
						  	},"fast");
						  		$("#tp1").css({"left": "200px"})
						  		$("#tp1").css({"transition": "all 1s ease"})
								//图片二去哪
						  	$("#tp2").animate({
						  		width:"700px",
						  		height:"700px"
						  	},"fast");
						  		$("#tp2").css({"left": "650px"})
						  		$("#tp2").css({"top": "200px"})
						  		$("#tp2").css({"transition": "all 1s ease"})
						  		//图片三去哪
						  	$("#tp3").animate({
						  		width:"340px",
						  		height:"340px"
						  	},"fast");
						  		$("#tp3").css({"left": "1450px"})
						  		//$("#tp3").css({"top": "550px"})
						  		$("#tp3").css({"transition": "all 1s ease"})
						  })
						  //***********************************************
						  $("#tp2").mouseout(function(){
						  	  //$("#tp1").css({"size":"100%"})
						  	 // $("#tp1").css({"height": "500px"})
						  	  //$("#tp1").css({"transition": "size 2s"})
						  	 $("#tp1").animate({
						  	 	width:"400px",
						  	 	height:"400px"
						  	 },"fast");
						  		$("#tp1").css({"left": "500px"})
						  		$("#tp1").css({"transition": "all 1s ease"})
						  	 
						  	 $("#tp2").animate({
						  	 		width:"400px",
						  	 		height:"400px"
						  	},"fast");
						  	 	$("#tp2").css({"left": "800px"})
						  	 	$("#tp2").css({"top": "350px"})
						  	 	$("#tp2").css({"transition": "all 1s ease"})
						  	 		
						  	$("#tp3").animate({
						  		width:"400px",
						  		height:"400px"
						  	},"fast");
						  	 	$("#tp3").css({"left": "1100px"})
						  	 	$("#tp3").css({"top": "205px"})
						  	 	$("#tp3").css({"transition": "all 1s ease"})
						  	 })
	 //**************************************************
	 $("#li3").mouseover(function(){
	 	  //图片一去哪
	 	$("#tp1").animate({
	 		width:"340px",
	 		height:"350px"
	 	},"fast");
	 		$("#tp1").css({"left": "400px"})
	 		$("#tp1").css({"transition": "all 1s ease"})
	 		//图片二去哪
	 	$("#tp2").animate({
	 		width:"340px",
	 		height:"350px"
	 	},"fast");
	 		$("#tp2").css({"left": "400px"})
	 		$("#tp2").css({"top": "570px"})
	 		$("#tp2").css({"transition": "all 1s ease"})
	 		//图片三去哪
	 	$("#tp3").animate({
	 		width:"700px",
	 		height:"700px"
	 	},"fast");
	 		$("#tp3").css({"left": "800px"})
	 		//$("#tp3").css({"top": "550px"})
	 		$("#tp3").css({"transition": "all 1s ease"})
	 })
	 //***********************************************
	 $("#li3").mouseout(function(){
	 	  //$("#tp1").css({"size":"100%"})
	 	 // $("#tp1").css({"height": "500px"})
	 	  //$("#tp1").css({"transition": "size 2s"})
	 	 $("#tp1").animate({
	 	 	width:"400px",
	 	 	height:"400px"
	 	 },"fast");
	 		$("#tp1").css({"left": "500px"})
	 		$("#tp1").css({"transition": "all 1s ease"})
	 	 
	 	 $("#tp2").animate({
	 	 		width:"400px",
	 	 		height:"400px"
	 	},"fast");
	 	 	$("#tp2").css({"left": "800px"})
	 	 	$("#tp2").css({"top": "350px"})
	 	 	$("#tp2").css({"transition": "all 1s ease"})
	 	 		
	 	$("#tp3").animate({
	 		width:"400px",
	 		height:"400px"
	 	},"fast");
	 	 	$("#tp3").css({"left": "1100px"})
	 	 	$("#tp3").css({"top": "205px"})
	 	 	$("#tp3").css({"transition": "all 1s ease"})
	 	 })
		
								//**************************************************
								$("#tp3").mouseover(function(){
									  //图片一去哪
									$("#tp1").animate({
										width:"340px",
										height:"350px"
									},"fast");
										$("#tp1").css({"left": "400px"})
										$("#tp1").css({"transition": "all 1s ease"})
										//图片二去哪
									$("#tp2").animate({
										width:"340px",
										height:"350px"
									},"fast");
										$("#tp2").css({"left": "400px"})
										$("#tp2").css({"top": "570px"})
										$("#tp2").css({"transition": "all 1s ease"})
										//图片三去哪
									$("#tp3").animate({
										width:"700px",
										height:"700px"
									},"fast");
										$("#tp3").css({"left": "800px"})
										//$("#tp3").css({"top": "550px"})
										$("#tp3").css({"transition": "all 1s ease"})
								})
								//***********************************************
								$("#tp3").mouseout(function(){
									  //$("#tp1").css({"size":"100%"})
									 // $("#tp1").css({"height": "500px"})
									  //$("#tp1").css({"transition": "size 2s"})
									 $("#tp1").animate({
									 	width:"400px",
									 	height:"400px"
									 },"fast");
										$("#tp1").css({"left": "500px"})
										$("#tp1").css({"transition": "all 1s ease"})
									 
									 $("#tp2").animate({
									 		width:"400px",
									 		height:"400px"
									},"fast");
									 	$("#tp2").css({"left": "800px"})
									 	$("#tp2").css({"top": "350px"})
									 	$("#tp2").css({"transition": "all 1s ease"})
									 		
									$("#tp3").animate({
										width:"400px",
										height:"400px"
									},"fast");
									 	$("#tp3").css({"left": "1100px"})
									 	$("#tp3").css({"top": "205px"})
									 	$("#tp3").css({"transition": "all 1s ease"})
									 })
	 $("#js-1").mouseover(function(){
		 $("#js1").animate({
		 	width:"850px",
			height:"50px"
		 },"normal");
		 $("#js2").animate({
		 	width:"850px",
		 	height:"650px"
		 },"normal");
		 
		 $("#js3").animate({
		 	width:"0px",
		 	height:"0px"
		 },"normal");
		 $("#js4").animate({
		 	width:"0px",
		 	height:"0px"
		 },"normal");
		 
		 $("#js5").animate({
		 	width:"0px",
		 				height:"0px"
		 },"normal");
		 $("#js6").animate({
		 	width:"0px",
		 	height:"1px"
		 },"normal");
	 	 })
	$("#js-1").mouseout(function(){
			
		 })
		 
	$("#js-2").mouseover(function(){
		 $("#js3").animate({
		 	width:"560px",
			height:"50px"
		 },"normal");
		 $("#js4").animate({
		 	width:"650px",
		 	height:"850px"
		 },"normal");
		 
		 $("#js1").animate({
		 	width:"0px",
		 				height:"0px"
		 },"normal");
		 $("#js2").animate({
		 	width:"0px",
		 	height:"0px"
		 },"normal");
		 
		 $("#js5").animate({
		 	width:"0px",
		 				height:"0px"
		 },"normal");
		 $("#js6").animate({
		 	width:"0px",
		 	height:"1px"
		 },"normal");
		 
	 	 })
	$("#js-2").mouseout(function(){
			
		 })
		 
	$("#js-3").mouseover(function(){
		 $("#js5").animate({
		 	width:"700px",
			height:"50px"
		 },"normal");
		 $("#js6").animate({
		 	width:"750px",
		 	height:"650px"
		 },"normal");
		 
		 
		 $("#js1").animate({
		 	width:"0px",
		 				height:"0px"
		 },"normal");
		 $("#js2").animate({
		 	width:"0px",
		 	height:"0px"
		 },"normal");
		 
		 $("#js3").animate({
		 	width:"0px",
		 	height:"0px"
		 },"normal");
		 $("#js4").animate({
		 	width:"0px",
		 	height:"0px"
		 },"normal");
		 
	 	 })
		 
	$("#js-3").mouseout(function(){
			 
		 })	 
		 
	/*$("#jszong").mouseover(function(){
		 $("#js1").animate({
		 	width:"850px",
			height:"50px"
		 },"normal");
		 $("#js2").animate({
		 	width:"850px",
		 	height:"650px"
		 },"normal");
	 		//$("#js1").css({"width": "850px"})
	 		//$("#tp1").css({"transition": "width 1s"})
	 	 })
	$("#jszong").mouseout(function(){
			 $("#js1").animate({
			 	width:"0px",
				height:"0px"
			 },"normal");
			 $("#js2").animate({
			 	width:"0px",
			 	height:"1px"
			 },"normal");
			//$("#js1").css({"width": "850px"})
			//$("#tp1").css({"transition": "width 1s"})
		 })*/
});
						