async function run(){
	
var koa=require('koa');
var Router=require('koa-router');
var swig = require('koa-swig');
var co=require('co');
var koaStaticCache=require('koa-static-cache');
var bodyParser=require('koa-bodyparser');
var mysql=require('mysql2/promise');

var app=new koa();
var router=new Router();

app.use(bodyParser());

app.use(koaStaticCache(__dirname+'/wenjian',{
	prefix:'/wenjian',
	gzip:true
}));

let datas={
	appName:"dates",
	list:[{name:1,email:2,password:3}]
}

const render=swig({
	root:__dirname+'/html', //模板存放目录
	autoescape:true,		//是否自动编码
	cache:false,			//是否缓存
	ext:'.html'				//模板后缀名
});

app.context.render=co.wrap(render);

const connection=await mysql.createConnection({
	host:'127.0.0.1',
	user:'root',
	password:'123456',
	database:'js19150138'
});



router.get('/', async (ctx, next)=>{
	//ctx.body="home page";
	ctx.body=await ctx.render('1zhuye.html');
});

router.get('/1zhuye.html', async (ctx, next)=>{
	//ctx.body=await ctx.render('add.html',{datas});
	ctx.body=await ctx.render('1zhuye.html');
});

router.get('/js19150138.html', async (ctx, next)=>{
	//ctx.body=await ctx.render('add.html',{datas});
	ctx.body=await ctx.render('js19150138.html');
});

router.get('/denglu.html', async (ctx, next)=>{
	//ctx.body=await ctx.render('add.html',{datas});
	ctx.body=await ctx.render('denglu.html');
});

router.get('/gyl.html', async (ctx, next)=>{
	//ctx.body=await ctx.render('add.html',{datas});
	ctx.body=await ctx.render('gyl.html');
});

router.post('/addshuju', async (ctx, next)=>{
	let name=ctx.request.body.name;
	let email=ctx.request.body.email;
	let password=ctx.request.body.password;
	let [insertResult]=await connection.query("INSERT INTO zhangchengli (name,email,password) VALUES('" + name + "','" + email + "','" + password + "')");
	let [dataArray]=await connection.query("select * from zhangchengli");
	
	let htmlStr =  '';
	for(let data of dataArray){
		htmlStr += `name:${data.name} \t email:${data.email}\t password:${data.password} \n`
	}
	ctx.body=htmlStr;
});

router.post('/delete',async(ctx, next)=>{
	let name=ctx.request.body.name;
	let email=ctx.request.body.email;
	let password=ctx.request.body.password;
	ctx.body="获取数据："+name+"-"+email+"-"+password;
	let name1=name,email1=email,password1=password;
	let [data]=await connection.query("delete from zhangchengli where name='"+name+"'");
	console.log(data);
	 if(data.affectedRows>0){
		 ctx.body={
			 code:0,
			 data:"删除成功"
		 }
	 }else{
		 ctx.body={
			 code:1,
			 data:"删除失败"
		 }
	 }
	 let [dataArray]=await connection.query("select * from zhangchengli");
	 let htmlStr =  '';
	 for(let data of dataArray){
	 	htmlStr += `name:${data.name} \t email:${data.email}\t password:${data.password} \n`
	 }
	 ctx.body=htmlStr;
});

router.post('/update',async(ctx, next)=>{
	let name=ctx.request.body.name;
	let email=ctx.request.body.email;
	let password=ctx.request.body.password;
	ctx.body="获取数据："+name+"-"+email+"-"+password;
	let name1=name,email1=email,password1=password;
	let [data]=await connection.query("update zhangchengli SET password='"+password+"'where name='"+name+"'");
	console.log(data);
	 if(data.affectedRows>0){
		 ctx.body={
			 code:0,
			 data:"修改成功"
		 }
	 }else{
		 ctx.body={
			 code:1,
			 data:"修改失败"
		 }
	 }
	 
});

router.get('/find', async ctx=>{
		 let [dataArray]=await connection.query("select * from zhangchengli");
		 let htmlStr =  '';
		 for(let data of dataArray){
		 	htmlStr += `name:${data.name} \t email:${data.email}\t password:${data.password} \n`
		 }
		 ctx.body=htmlStr;
	 });
	 
app.use(async (ctx, next)=>{
	await ctx.set('Access-Control-Allow-Origin', '*');
	await next();
});

app.use(router.routes());

app.listen(8089);
};


run();

